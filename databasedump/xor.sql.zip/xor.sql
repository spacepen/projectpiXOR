-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 25. Jun 2017 um 19:08
-- Server-Version: 10.1.22-MariaDB
-- PHP-Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `xor`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `question`
--

CREATE TABLE `question` (
  `questionID` int(11) NOT NULL,
  `questionName` varchar(255) NOT NULL,
  `answerA` varchar(100) NOT NULL,
  `answerB` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `question`
--

INSERT INTO `question` (`questionID`, `questionName`, `answerA`, `answerB`) VALUES
(1, 'In der Mittagspause zum ...', 'Schl&ouml;gl', 'H&ouml;rtnagel'),
(2, 'Wo kann man besser feiern gehen?', 'Schenke', 'Pure'),
(3, 'Bier auf Wein ...', 'das lass sein', 'passt immer rein'),
(4, 'Was trinkst du lieber?', 'Gin', 'Vodka'),
(5, 'Als Haustier magst du lieber ...', 'Hund', 'Katze'),
(6, 'Du bist begeisteter ...', 'Apple-User', 'Microsoft-User'),
(7, 'In Wahrheit ist die Erde ...', 'flach', 'eine Kugel'),
(8, 'Wenn du die Wahl hast, entweder für die Klausur zu lernen oder deine Wohnung zu putzen, welche Serie schaust du dann?', 'Modern Family', 'Game of Thrones'),
(9, 'Welche App benützt du lieber?', 'Snapchat', 'Instagram'),
(10, 'Im Winter lieber ...', 'Snowboarden', 'Skifahren');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userquestion`
--

CREATE TABLE `userquestion` (
  `selection` tinyint(1) NOT NULL,
  `usersID` int(11) NOT NULL,
  `questionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `usersID` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`usersID`, `email`, `password`) VALUES
(1, 'max@mustermann.at', '123456'),
(2, 'alexandra.kaltschmid@gmx.at', 'lol');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`questionID`);

--
-- Indizes für die Tabelle `userquestion`
--
ALTER TABLE `userquestion`
  ADD KEY `usersID` (`usersID`),
  ADD KEY `questionID` (`questionID`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usersID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `question`
--
ALTER TABLE `question`
  MODIFY `questionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
  MODIFY `usersID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `userquestion`
--
ALTER TABLE `userquestion`
  ADD CONSTRAINT `userquestion_ibfk_1` FOREIGN KEY (`usersID`) REFERENCES `users` (`usersID`),
  ADD CONSTRAINT `userquestion_ibfk_2` FOREIGN KEY (`questionID`) REFERENCES `question` (`questionID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
